package com.example.prakticheskaya3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PrakticheskayaRabota3Application {
    public static void main(String[] args) {
        SpringApplication.run(PrakticheskayaRabota3Application.class, args);
    }
}
