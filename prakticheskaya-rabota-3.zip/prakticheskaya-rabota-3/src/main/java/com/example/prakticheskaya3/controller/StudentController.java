package com.example.prakticheskaya3.controller;

import com.example.prakticheskaya3.model.Student;
import com.example.prakticheskaya3.service.StudentService;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class StudentController {

    private final StudentService studentService;

    public StudentController(StudentService studentService) {
        this.studentService = studentService;
    }

    private boolean isLoggedIn(HttpSession session) {
        return session.getAttribute("loggedInUser") != null;
    }

    @GetMapping("/")
    public String root(HttpSession session) {
        return isLoggedIn(session) ? "redirect:/students" : "redirect:/login";
    }

    @GetMapping("/students")
    public String studentsList(HttpSession session, Model model) {
        if (!isLoggedIn(session)) {
            return "redirect:/login";
        }
        model.addAttribute("students", studentService.getAllStudents());
        return "students-list";
    }

    @GetMapping("/students/add")
    public String addForm(HttpSession session, Model model) {
        if (!isLoggedIn(session)) {
            return "redirect:/login";
        }
        model.addAttribute("student", new Student());
        return "students-form";
    }

    @PostMapping("/students/add")
    public String addStudent(HttpSession session,
                             @RequestParam String name,
                             @RequestParam String course,
                             @RequestParam(defaultValue = "false") Boolean hasDebt) {
        if (!isLoggedIn(session)) {
            return "redirect:/login";
        }
        studentService.saveStudent(new Student(name, course, hasDebt));
        return "redirect:/students";
    }
}
