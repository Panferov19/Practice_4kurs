package com.example.prakticheskaya3.repository;

import com.example.prakticheskaya3.model.Student;
import org.springframework.data.jpa.repository.JpaRepository;

public interface StudentRepository extends JpaRepository<Student, Long> {
}
