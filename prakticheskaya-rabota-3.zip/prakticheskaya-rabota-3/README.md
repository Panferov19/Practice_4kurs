# Практическая работа 3

Spring Boot приложение для:
- регистрации и входа пользователя;
- защиты списка студентов через сессию;
- добавления студентов.

## Запуск
```bash
mvn spring-boot:run
```

Открыть:
- http://localhost:8080/register
- http://localhost:8080/login
- http://localhost:8080/students
