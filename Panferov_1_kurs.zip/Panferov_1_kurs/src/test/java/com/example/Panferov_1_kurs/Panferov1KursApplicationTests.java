package com.example.Panferov_1_kurs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Panferov1KursApplicationTests {

    @Test
    void contextLoads() {
    }

}
