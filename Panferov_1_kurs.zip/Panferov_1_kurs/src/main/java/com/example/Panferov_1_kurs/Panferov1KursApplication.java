package com.example.Panferov_1_kurs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Panferov1KursApplication {

    public static void main(String[] args) {
        SpringApplication.run(Panferov1KursApplication.class, args);
    }

}
