package com.example.Panferov_1_kurs;

import com.example.Panferov_1_kurs.model.Student;
import com.example.Panferov_1_kurs.repository.StudentRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class DataInitializer implements CommandLineRunner {

    private final StudentRepository studentRepository;

    public DataInitializer(StudentRepository studentRepository) {
        this.studentRepository = studentRepository;
    }

    @Override
    public void run(String... args) throws Exception {
        if (studentRepository.count() == 0) {
            studentRepository.save(new Student("Иван Иванов", 19, 110, "ИВТ-101"));
            studentRepository.save(new Student("Петр Петров", 20, 115, "ИВТ-101"));
            studentRepository.save(new Student("Анна Сидорова", 18, 125, "ИВТ-102"));
            studentRepository.save(new Student("Алексей Панферов", 19, 120, "ИВТ-101"));
        }
    }
}
