package com.example.Panferov_1_kurs.service;

import com.example.Panferov_1_kurs.model.Student;
import com.example.Panferov_1_kurs.repository.StudentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class StudentService {

    private final StudentRepository studentRepository;

    @Autowired
    public StudentService(StudentRepository studentRepository) {
        this.studentRepository = studentRepository;
    }

    public List<Student> getAllStudents() {
        return studentRepository.findAll();
    }

    public Optional<Student> getStudentById(Long id) {
        return studentRepository.findById(id);
    }

    public Student saveStudent(Student student) {
        return studentRepository.save(student);
    }

    public void deleteStudentById(Long id) {
        studentRepository.deleteById(id);
    }

    public List<Student> searchByName(String name) {
        if (name != null && !name.trim().isEmpty()) {
            return studentRepository.findByNameContainingIgnoreCase(name);
        }
        return getAllStudents();
    }
}
