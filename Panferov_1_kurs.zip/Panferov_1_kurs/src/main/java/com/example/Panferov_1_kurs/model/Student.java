package com.example.Panferov_1_kurs.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

@Entity
@Table(name = "students")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Student {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "name", nullable = false)
    private String name;

    @Column(name = "age")
    private int age;

    @Column(name = "iq")
    private int iq;

    @Column(name = "student_group")
    private String group;

    public Student(String name, int age, int iq, String group) {
        this.name = name;
        this.age = age;
        this.iq = iq;
        this.group = group;
    }
}
