package com.example.employees.repository;

import com.example.employees.model.Employee;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface EmployeeRepository extends JpaRepository<Employee, Long> {

    boolean existsByEmailIgnoreCase(String email);

    Optional<Employee> findByEmailIgnoreCase(String email);

    List<Employee> findByFullNameContainingIgnoreCase(String fullName);

    List<Employee> findByActive(boolean active);

    List<Employee> findByFullNameContainingIgnoreCaseAndActive(String fullName, boolean active);
}
