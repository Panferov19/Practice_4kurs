package com.example.employees.service;

import com.example.employees.exception.EmployeeNotFoundException;
import com.example.employees.model.Employee;
import com.example.employees.repository.EmployeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.List;

@Service
public class EmployeeService {

    @Autowired
    private EmployeeRepository employeeRepository;

    public List<Employee> search(String name, Boolean active) {
        String normalizedName = StringUtils.hasText(name) ? name.trim() : null;

        if (normalizedName != null && active != null) {
            return employeeRepository.findByFullNameContainingIgnoreCaseAndActive(normalizedName, active);
        }
        if (normalizedName != null) {
            return employeeRepository.findByFullNameContainingIgnoreCase(normalizedName);
        }
        if (active != null) {
            return employeeRepository.findByActive(active);
        }
        return employeeRepository.findAll(Sort.by(Sort.Direction.ASC, "fullName"));
    }

    public Employee getById(Long id) {
        return employeeRepository.findById(id)
                .orElseThrow(() -> new EmployeeNotFoundException(id));
    }

    public boolean emailExists(String email) {
        if (!StringUtils.hasText(email)) {
            return false;
        }
        return employeeRepository.existsByEmailIgnoreCase(email.trim());
    }

    public Employee save(Employee employee) {
        normalize(employee);
        return employeeRepository.save(employee);
    }

    public void delete(Long id) {
        employeeRepository.deleteById(id);
    }

    public boolean emailExistsForAnotherEmployee(String email, Long id) {
        if (!StringUtils.hasText(email)) {
            return false;
        }
        return employeeRepository.findByEmailIgnoreCase(email.trim())
                .map(existing -> !existing.getId().equals(id))
                .orElse(false);
    }

    private void normalize(Employee employee) {
        if (employee.getFullName() != null) {
            employee.setFullName(employee.getFullName().trim());
        }
        if (employee.getEmail() != null) {
            employee.setEmail(employee.getEmail().trim().toLowerCase());
        }
        if (employee.getPhone() != null) {
            employee.setPhone(employee.getPhone().trim());
        }
        if (employee.getPosition() != null) {
            employee.setPosition(employee.getPosition().trim());
        }
    }
}
