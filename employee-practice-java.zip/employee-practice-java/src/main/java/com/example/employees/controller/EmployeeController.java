package com.example.employees.controller;

import com.example.employees.model.Employee;
import com.example.employees.service.EmployeeService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/employees")
public class EmployeeController {

    @Autowired
    private EmployeeService employeeService;

    @GetMapping
    public String list(@RequestParam(required = false) String name,
                       @RequestParam(required = false) String active,
                       Model model) {
        model.addAttribute("employees", employeeService.search(name, parseActive(active)));
        model.addAttribute("name", name);
        model.addAttribute("active", active == null ? "all" : active);
        return "employees-list";
    }

    @GetMapping("/add")
    public String addForm(Model model) {
        model.addAttribute("employee", new Employee());
        return "employee-form";
    }

    @PostMapping("/add")
    public String add(@Valid @ModelAttribute("employee") Employee employee,
                      BindingResult bindingResult,
                      Model model) {
        return saveEmployee(employee, bindingResult, model, null);
    }

    @GetMapping("/edit/{id}")
    public String editForm(@PathVariable Long id, Model model) {
        model.addAttribute("employee", employeeService.getById(id));
        return "employee-form";
    }

    @PostMapping("/edit/{id}")
    public String edit(@PathVariable Long id,
                       @Valid @ModelAttribute("employee") Employee employee,
                       BindingResult bindingResult,
                       Model model) {
        employee.setId(id);
        return saveEmployee(employee, bindingResult, model, id);
    }

    @PostMapping("/delete/{id}")
    public String delete(@PathVariable Long id) {
        employeeService.delete(id);
        return "redirect:/employees";
    }

    private String saveEmployee(Employee employee, BindingResult bindingResult, Model model, Long currentId) {
        if (employeeService.emailExistsForAnotherEmployee(employee.getEmail(), currentId)) {
            bindingResult.rejectValue("email", "email.exists", "Сотрудник с таким email уже существует");
        }

        if (bindingResult.hasErrors()) {
            model.addAttribute("employee", employee);
            return "employee-form";
        }

        employeeService.save(employee);
        return "redirect:/employees";
    }

    private Boolean parseActive(String active) {
        if (active == null || active.isBlank() || "all".equalsIgnoreCase(active)) {
            return null;
        }
        return Boolean.valueOf(active);
    }
}
