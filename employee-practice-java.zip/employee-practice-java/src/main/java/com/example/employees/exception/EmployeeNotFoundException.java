package com.example.employees.exception;

public class EmployeeNotFoundException extends RuntimeException {
    public EmployeeNotFoundException(Long id) {
        super("Сотрудник с id=" + id + " не найден");
    }
}
