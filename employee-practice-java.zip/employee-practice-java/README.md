# Практическая работа №2 — Учёт сотрудников

## Что реализовано
- список сотрудников;
- поиск по ФИО;
- фильтр по активности;
- добавление сотрудника с валидацией;
- редактирование сотрудника;
- удаление сотрудника;
- H2 in-memory база данных;
- Thymeleaf-шаблоны.

## Требования\n- JDK 21\n- Maven 3.6.3 или новее\n\nВ IntelliJ IDEA выберите JDK 21 для Project SDK и Maven Runner.\n\n## Запуск
```bash
mvn spring-boot:run
```

Откройте:
`http://localhost:8080/employees`

H2 console:
`http://localhost:8080/h2-console`
JDBC URL: `jdbc:h2:mem:testdb`
User: `sa`
Password: пусто
